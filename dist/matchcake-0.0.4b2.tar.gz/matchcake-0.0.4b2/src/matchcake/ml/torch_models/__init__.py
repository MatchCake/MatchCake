from .torch_model import TorchModel
from .nif_torch_model import NIFTorchModel