from .nif_device import NonInteractingFermionicDevice
from .nif_device import NonInteractingFermionicDevice as NIFDevice  # Alias
